﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace TechRepairApp
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            string login = loginTxt.Text;
            string password = passwordTxt.Text;

            using (var context = new TrainingDbEntities())
            {
                var user = context.Users.FirstOrDefault(u => u.login == login && u.password == password);

                if (user != null)
                {
                    MessageBox.Show("Успешный вход!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RequestsForm requestsForm = new RequestsForm(user);
                    requestsForm.Show();
                }
                else 
                {
                    MessageBox.Show("Неправильный логин или пароль.", "Ошибка входа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
