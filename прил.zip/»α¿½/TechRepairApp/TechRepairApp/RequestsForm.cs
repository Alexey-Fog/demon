﻿using System;
using System.Windows.Forms;

namespace TechRepairApp
{
    public partial class RequestsForm : Form
    {
        private TrainingDbDataSetTableAdapters.RequestsTableAdapter requestsTableAdapter;
        private TrainingDbDataSetTableAdapters.StatusesTableAdapter statusesTableAdapter;
        private TrainingDbDataSetTableAdapters.UsersTableAdapter usersTableAdapter;
        private TrainingDbDataSetTableAdapters.TechTypesTableAdapter techTypesTableAdapter;
        private BindingSource bindingSource;

        private Users currentUser;
        
        public RequestsForm(Users user)
        {
            InitializeComponent();
            requestsTableAdapter = new TrainingDbDataSetTableAdapters.RequestsTableAdapter();
            statusesTableAdapter = new TrainingDbDataSetTableAdapters.StatusesTableAdapter();
            usersTableAdapter = new TrainingDbDataSetTableAdapters.UsersTableAdapter();
            techTypesTableAdapter = new TrainingDbDataSetTableAdapters.TechTypesTableAdapter();
            bindingSource = new BindingSource();

            currentUser = user;
            if (currentUser.roleID == 2)
            {
                addRequestBtn.Enabled = false;
                deleteRequestBtn.Enabled = false;
            }
        }

        private void RequestsForm_Load(object sender, EventArgs e)
        {
            requestDetailsViewTableAdapter.Fill(trainingDbDataSet.RequestDetailsView);
            bindingSource.DataSource = trainingDbDataSet.RequestDetailsView;
            requestDetailsViewDataGridView.DataSource = bindingSource;
            
            requestsTableAdapter.Fill(trainingDbDataSet.Requests);
            statusesTableAdapter.Fill(trainingDbDataSet.Statuses);
            usersTableAdapter.Fill(trainingDbDataSet.Users);
            techTypesTableAdapter.Fill(trainingDbDataSet.TechTypes);
        }

        private void searchByIdBtn_Click(object sender, EventArgs e)
        {
            if (int.TryParse(searchByIdTxt.Text, out var requestId))
            {
                bindingSource.Filter = $"requestID = {requestId}";
                if (bindingSource.Count == 0)
                {
                    MessageBox.Show("Заявки с таким ID не существует", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Введите корретный номер заявки", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clearFilterBtn_Click(object sender, EventArgs e)
        {
            bindingSource.RemoveFilter();
        }

        private void searchByIdTxt_TextChanged(object sender, EventArgs e)
        {
            searchByIdBtn.Enabled = !string.IsNullOrWhiteSpace(searchByIdTxt.Text);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var qrForm = new QrForm();
            qrForm.ShowDialog();
        }

        private void requestDetailsViewDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int requestId = (int)requestDetailsViewDataGridView.Rows[e.RowIndex].Cells["requestID"].Value;
                EditRequest(requestId);
            }
        }

        private void EditRequest(int requestId)
        {
            var editForm = new EditRequestForm(requestId, trainingDbDataSet);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show($"Запись с ID={requestId} изменена!", "Редактирование записи", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void addRequestBtn_Click(object sender, EventArgs e)
        {
            var addForm = new AddRequestForm(trainingDbDataSet);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("Новая запись добавлена!", "Добавление записи", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void DeleteRequest(int requestId, TrainingDbDataSet.RequestsDataTable Requests)
        {
            var requestRow = Requests.FindByrequestID(requestId);
            if (requestRow != null)
            {
                requestRow.Delete();
                requestsTableAdapter.Update(trainingDbDataSet.Requests);
            }
        }

        private void deleteRequestBtn_Click(object sender, EventArgs e)
        {
            if (requestDetailsViewDataGridView.SelectedRows.Count > 0)
            {
                int requestId = (int)requestDetailsViewDataGridView.SelectedRows[0].Cells["requestID"].Value;
                DeleteRequest(requestId, trainingDbDataSet.Requests);
                MessageBox.Show($"Запись с ID={requestId} удалена!", "Удаление записи", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.", "Удаление записи", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
