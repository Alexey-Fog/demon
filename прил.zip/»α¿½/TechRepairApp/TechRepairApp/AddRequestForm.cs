using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace TechRepairApp
{
    public partial class AddRequestForm : Form
    {
        private TrainingDbDataSet trainingDbDataSet;
        private TrainingDbDataSetTableAdapters.RequestsTableAdapter requestsTableAdapter;

        public AddRequestForm(TrainingDbDataSet dataSet)
        {
            InitializeComponent();
            trainingDbDataSet = dataSet;
            requestsTableAdapter = new TrainingDbDataSetTableAdapters.RequestsTableAdapter();
            LoadRequestData();
        }

        private void LoadRequestData()
        {

            SetCbo(techTypeCbo, "techTypeName", "techTypeID", trainingDbDataSet.TechTypes);
            SetCbo(statusCbo, "statusName", "statusID", trainingDbDataSet.Statuses);
            SetCbo(masterCbo, "lastName", "userID", trainingDbDataSet.Users.Where(user => user.roleID == 2).ToList());
            SetCbo(clientCbo, "lastName", "userID", trainingDbDataSet.Users.Where(user => user.roleID == 4).ToList());
        }

        private void SetCbo(ComboBox cbo, string displayMember, string valueMember, object cboData)
        {
            cbo.DataSource = cboData;
            cbo.DisplayMember = displayMember;
            cbo.ValueMember = valueMember;
        }

        public void AddRequest(DateTime startDate, DateTime completionDate, int techTypeID, string model,
            string problemDescription, int requestStatusID, int masterID, int clientID)
        {
            var newRow = trainingDbDataSet.Requests.NewRequestsRow();

            newRow.startDate = startDate;
            newRow.completionDate = completionDate;
            newRow.orgTechTypeID = techTypeID;
            newRow.orgTechModel = model;
            newRow.problemDescryption = problemDescription;
            newRow.requestStatusID = requestStatusID;
            newRow.masterID = masterID;
            newRow.clientID = clientID;

            trainingDbDataSet.Requests.AddRequestsRow(newRow);
            requestsTableAdapter.Update(trainingDbDataSet.Requests);
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                AddRequest(startDate.Value, 
                    completionDate.Value, 
                    (int)techTypeCbo.SelectedValue, 
                    modelTxt.Text, 
                    problemDescriptionTxt.Text, 
                    (int)statusCbo.SelectedValue, 
                    (int)masterCbo.SelectedValue, 
                    (int)clientCbo.SelectedValue);

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("������ ��� ���������� ����� ������: " + ex.Message, "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancelBtn_Click(object sender, System.EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}