﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace TechRepairApp
{
    public partial class EditRequestForm : Form
    {
        private TrainingDbDataSet trainingDbDataSet;
        private int requestId;
        private TrainingDbDataSetTableAdapters.RequestsTableAdapter requestsTableAdapter;

        public EditRequestForm(int requestId, TrainingDbDataSet dataSet)
        {
            InitializeComponent();
            this.requestId = requestId;
            trainingDbDataSet = dataSet;
            requestsTableAdapter = new TrainingDbDataSetTableAdapters.RequestsTableAdapter();
            LoadRequestData();
        }

        private void LoadRequestData() 
        { 
            var requestRow = trainingDbDataSet.Requests.FindByrequestID(requestId);

            problemDescriptionTxt.Text = requestRow.problemDescryption;

            statusCbo.DataSource = trainingDbDataSet.Statuses;
            statusCbo.DisplayMember = "statusName";
            statusCbo.ValueMember = "statusID";

            masterCbo.DataSource = trainingDbDataSet.Users.Where(user => user.roleID == 2).ToList();
            masterCbo.DisplayMember = "lastName";
            masterCbo.ValueMember = "userID";
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            var requestRow = trainingDbDataSet.Requests.FindByrequestID(requestId);

            requestRow.problemDescryption = problemDescriptionTxt.Text;
            requestRow.requestStatusID = (int)statusCbo.SelectedValue;
            requestRow.masterID = (int)masterCbo.SelectedValue;
            
            requestsTableAdapter.Update(trainingDbDataSet.Requests);

            DialogResult = DialogResult.OK;
            Close();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
