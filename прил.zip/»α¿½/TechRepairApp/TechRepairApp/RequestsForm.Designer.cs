﻿namespace TechRepairApp
{
    partial class RequestsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RequestsForm));
            this.requestsDetailsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.requestsDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trainingDbDataSet = new TechRepairApp.TrainingDbDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.requestsDetailsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.searchByIdTxt = new System.Windows.Forms.TextBox();
            this.searchByIdBtn = new System.Windows.Forms.Button();
            this.clearFilterBtn = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.requestDetailsViewDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.requestDetailsViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.requestsDetailsTableAdapter = new TechRepairApp.TrainingDbDataSetTableAdapters.RequestsDetailsTableAdapter();
            this.tableAdapterManager = new TechRepairApp.TrainingDbDataSetTableAdapters.TableAdapterManager();
            this.requestDetailsViewTableAdapter = new TechRepairApp.TrainingDbDataSetTableAdapters.RequestDetailsViewTableAdapter();
            this.addRequestBtn = new System.Windows.Forms.Button();
            this.deleteRequestBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.requestsDetailsBindingNavigator)).BeginInit();
            this.requestsDetailsBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.requestsDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainingDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestDetailsViewDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestDetailsViewBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // requestsDetailsBindingNavigator
            // 
            this.requestsDetailsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.requestsDetailsBindingNavigator.BindingSource = this.requestsDetailsBindingSource;
            this.requestsDetailsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.requestsDetailsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.requestsDetailsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.requestsDetailsBindingNavigatorSaveItem});
            this.requestsDetailsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.requestsDetailsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.requestsDetailsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.requestsDetailsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.requestsDetailsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.requestsDetailsBindingNavigator.Name = "requestsDetailsBindingNavigator";
            this.requestsDetailsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.requestsDetailsBindingNavigator.Size = new System.Drawing.Size(1056, 25);
            this.requestsDetailsBindingNavigator.TabIndex = 0;
            this.requestsDetailsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // requestsDetailsBindingSource
            // 
            this.requestsDetailsBindingSource.DataMember = "RequestsDetails";
            this.requestsDetailsBindingSource.DataSource = this.trainingDbDataSet;
            // 
            // trainingDbDataSet
            // 
            this.trainingDbDataSet.DataSetName = "TrainingDbDataSet";
            this.trainingDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // requestsDetailsBindingNavigatorSaveItem
            // 
            this.requestsDetailsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.requestsDetailsBindingNavigatorSaveItem.Enabled = false;
            this.requestsDetailsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("requestsDetailsBindingNavigatorSaveItem.Image")));
            this.requestsDetailsBindingNavigatorSaveItem.Name = "requestsDetailsBindingNavigatorSaveItem";
            this.requestsDetailsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.requestsDetailsBindingNavigatorSaveItem.Text = "Save Data";
            this.requestsDetailsBindingNavigatorSaveItem.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(327, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Просмотр заявок";
            // 
            // searchByIdTxt
            // 
            this.searchByIdTxt.Location = new System.Drawing.Point(877, 73);
            this.searchByIdTxt.Name = "searchByIdTxt";
            this.searchByIdTxt.Size = new System.Drawing.Size(147, 20);
            this.searchByIdTxt.TabIndex = 3;
            this.searchByIdTxt.TextChanged += new System.EventHandler(this.searchByIdTxt_TextChanged);
            // 
            // searchByIdBtn
            // 
            this.searchByIdBtn.Enabled = false;
            this.searchByIdBtn.Location = new System.Drawing.Point(877, 99);
            this.searchByIdBtn.Name = "searchByIdBtn";
            this.searchByIdBtn.Size = new System.Drawing.Size(147, 23);
            this.searchByIdBtn.TabIndex = 4;
            this.searchByIdBtn.Text = "Поиск по ID";
            this.searchByIdBtn.UseVisualStyleBackColor = true;
            this.searchByIdBtn.Click += new System.EventHandler(this.searchByIdBtn_Click);
            // 
            // clearFilterBtn
            // 
            this.clearFilterBtn.Location = new System.Drawing.Point(877, 128);
            this.clearFilterBtn.Name = "clearFilterBtn";
            this.clearFilterBtn.Size = new System.Drawing.Size(147, 23);
            this.clearFilterBtn.TabIndex = 5;
            this.clearFilterBtn.Text = "Сбросить поиск";
            this.clearFilterBtn.UseVisualStyleBackColor = true;
            this.clearFilterBtn.Click += new System.EventHandler(this.clearFilterBtn_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(383, 360);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(45, 13);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "ссылке";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 360);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(355, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Чтобы оствить отзыв по качеству выполнения заявки перейдите по";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(434, 360);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "и просканируйте QR - код";
            // 
            // requestDetailsViewDataGridView
            // 
            this.requestDetailsViewDataGridView.AllowUserToAddRows = false;
            this.requestDetailsViewDataGridView.AutoGenerateColumns = false;
            this.requestDetailsViewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.requestDetailsViewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.requestDetailsViewDataGridView.DataSource = this.requestDetailsViewBindingSource;
            this.requestDetailsViewDataGridView.Location = new System.Drawing.Point(27, 73);
            this.requestDetailsViewDataGridView.Name = "requestDetailsViewDataGridView";
            this.requestDetailsViewDataGridView.Size = new System.Drawing.Size(833, 257);
            this.requestDetailsViewDataGridView.TabIndex = 8;
            this.requestDetailsViewDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.requestDetailsViewDataGridView_CellDoubleClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "requestID";
            this.dataGridViewTextBoxColumn1.HeaderText = "requestID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "startDate";
            this.dataGridViewTextBoxColumn2.HeaderText = "startDate";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "orgTechTypeName";
            this.dataGridViewTextBoxColumn3.HeaderText = "orgTechTypeName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "orgTechModel";
            this.dataGridViewTextBoxColumn4.HeaderText = "orgTechModel";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "problemDescryption";
            this.dataGridViewTextBoxColumn5.HeaderText = "problemDescryption";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "requestStatusName";
            this.dataGridViewTextBoxColumn6.HeaderText = "requestStatusName";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "masterName";
            this.dataGridViewTextBoxColumn7.HeaderText = "masterName";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "clientName";
            this.dataGridViewTextBoxColumn8.HeaderText = "clientName";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // requestDetailsViewBindingSource
            // 
            this.requestDetailsViewBindingSource.DataMember = "RequestDetailsView";
            this.requestDetailsViewBindingSource.DataSource = this.trainingDbDataSet;
            // 
            // requestsDetailsTableAdapter
            // 
            this.requestsDetailsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CommentsTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.RepairPartsTableAdapter = null;
            this.tableAdapterManager.RequestsTableAdapter = null;
            this.tableAdapterManager.RolesTableAdapter = null;
            this.tableAdapterManager.StatusesTableAdapter = null;
            this.tableAdapterManager.TechTypesTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TechRepairApp.TrainingDbDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsersTableAdapter = null;
            // 
            // requestDetailsViewTableAdapter
            // 
            this.requestDetailsViewTableAdapter.ClearBeforeFill = true;
            // 
            // addRequestBtn
            // 
            this.addRequestBtn.Location = new System.Drawing.Point(877, 276);
            this.addRequestBtn.Name = "addRequestBtn";
            this.addRequestBtn.Size = new System.Drawing.Size(147, 23);
            this.addRequestBtn.TabIndex = 9;
            this.addRequestBtn.Text = "Добавить заявку";
            this.addRequestBtn.UseVisualStyleBackColor = true;
            this.addRequestBtn.Click += new System.EventHandler(this.addRequestBtn_Click);
            // 
            // deleteRequestBtn
            // 
            this.deleteRequestBtn.Location = new System.Drawing.Point(877, 307);
            this.deleteRequestBtn.Name = "deleteRequestBtn";
            this.deleteRequestBtn.Size = new System.Drawing.Size(147, 23);
            this.deleteRequestBtn.TabIndex = 10;
            this.deleteRequestBtn.Text = "Удалить заявку";
            this.deleteRequestBtn.UseVisualStyleBackColor = true;
            this.deleteRequestBtn.Click += new System.EventHandler(this.deleteRequestBtn_Click);
            // 
            // RequestsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 402);
            this.Controls.Add(this.deleteRequestBtn);
            this.Controls.Add(this.addRequestBtn);
            this.Controls.Add(this.requestDetailsViewDataGridView);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.clearFilterBtn);
            this.Controls.Add(this.searchByIdBtn);
            this.Controls.Add(this.searchByIdTxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.requestsDetailsBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "RequestsForm";
            this.Text = "RequestsForm";
            this.Load += new System.EventHandler(this.RequestsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.requestsDetailsBindingNavigator)).EndInit();
            this.requestsDetailsBindingNavigator.ResumeLayout(false);
            this.requestsDetailsBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.requestsDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainingDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestDetailsViewDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestDetailsViewBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button addRequestBtn;
        private System.Windows.Forms.Button deleteRequestBtn;

        #endregion

        private TrainingDbDataSet trainingDbDataSet;
        private System.Windows.Forms.BindingSource requestsDetailsBindingSource;
        private TrainingDbDataSetTableAdapters.RequestsDetailsTableAdapter requestsDetailsTableAdapter;
        private TrainingDbDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator requestsDetailsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton requestsDetailsBindingNavigatorSaveItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox searchByIdTxt;
        private System.Windows.Forms.Button searchByIdBtn;
        private System.Windows.Forms.Button clearFilterBtn;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource requestDetailsViewBindingSource;
        private TrainingDbDataSetTableAdapters.RequestDetailsViewTableAdapter requestDetailsViewTableAdapter;
        private System.Windows.Forms.DataGridView requestDetailsViewDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
    }
}