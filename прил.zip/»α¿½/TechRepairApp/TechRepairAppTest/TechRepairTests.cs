﻿using NUnit.Framework;
using System;
using System.Linq;
using TechRepairApp;
using TechRepairApp.TrainingDbDataSetTableAdapters;

namespace TechRepairAppTest
{
    [TestFixture]
    public class TechRepairTests
    {
        private TrainingDbDataSet trainingDbDataSet;
        private AddRequestForm addRequestForm;
        private RequestsForm requestsForm;

        [SetUp]
        public void Setup()
        {
            trainingDbDataSet = new TrainingDbDataSet();
            addRequestForm = new AddRequestForm(trainingDbDataSet);
            requestsForm = new RequestsForm(null);
        }

        [TestCase("GANSOR-1301880")]
        public void CreateRequest_Test(string model)
        {
            addRequestForm.AddRequest(DateTime.Now,DateTime.Now.AddDays(3), 1, model,null, 1, 2, 3);

            var newRow = trainingDbDataSet.Requests.OrderByDescending(r => r.requestID).FirstOrDefault();

            Assert.That(newRow, Is.Not.Null);
            Assert.That(model, Is.EqualTo(newRow.orgTechModel));
        }

        [Test]
        public void DeleteLastRequest_Test()
        {
            int origRowsQty = trainingDbDataSet.Requests.Count;
            var lastRowID = trainingDbDataSet.Requests.OrderByDescending(r => r.requestID).FirstOrDefault().requestID;
            requestsForm.DeleteRequest(lastRowID, trainingDbDataSet.Requests);
            int rowsQtyAfterDeletion = trainingDbDataSet.Requests.Count;
            
            Assert.That(origRowsQty - 1, Is.EqualTo(rowsQtyAfterDeletion));
        }
    }
}
